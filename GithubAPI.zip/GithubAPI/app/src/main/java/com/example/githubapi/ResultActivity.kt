package com.example.githubapi

import android.app.Activity
import android.app.NotificationChannelGroup
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Camera
import android.net.Uri
import android.os.*
import android.provider.MediaStore
import android.util.Log
import android.view.ActionMode
import android.view.View
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.FileProvider
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import kotlinx.android.synthetic.main.activity_result.*
import kotlinx.coroutines.*
import java.io.File
import java.io.IOException
import java.lang.Runnable
import java.text.SimpleDateFormat
import java.util.*
import java.util.jar.Manifest
import kotlin.concurrent.timer


class ResultActivity : AppCompatActivity() {

    val handler = Handler()
    private var timeValue = 0

    private var sec_pay_result = 0.0 //초당 급여
    private var min_pay_result = 0.0 //분당 급여
    private var time_limit = 0
    private val OPEN_GALLERY = 1
    private var salary_count = 0

    private var mBackWait : Long = 0 //뒤로가기

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_result)

        var pay_text :Double

        // 완료버튼
        if(timeover.getVisibility() == View.VISIBLE)
            timeover.setVisibility(View.INVISIBLE)
        //만약 타임오버 버튼이 보이면 숨기고

        //갤러리
        camera.setOnClickListener{
            openGallery()
        }//갤러리 버튼

        //데이터를 파이어베이스 디비에서 받아오기
        FirebaseDatabase.getInstance().getReference()
            .child(intent.getStringExtra("uid")) //넘어온 uid받아옴
              .addListenerForSingleValueEvent(object:ValueEventListener{
                  override fun onCancelled(p0: DatabaseError) {
                        //실패했을 때
                      //Toast.makeText(this, "DB로딩 실패" , Toast.LENGTH_SHORT).show()
                  }


                  @RequiresApi(Build.VERSION_CODES.O)
                  override fun onDataChange(p0: DataSnapshot) {
                      //성공햇을 때
                      val DataFromFB = p0.getValue(Data::class.java)
                      //여기서 받아온 값들을 id값에다 넣어줌

                      //////////////////////////////////////////////////////////////////////
                      //월급 -> 초당급여
                      ///////////////////////////////////////////////////////////////////////

                      var salary = DataFromFB?.salary
                      var work_time = DataFromFB?.work_time
                      var work_day = DataFromFB?.work_day
                      //val work_start = DataFromFB?.work_start

                      var hour_pay = salary?.div(work_day!!.toDouble())?.div(work_time!!.toDouble())
                      var min_pay = hour_pay?.div(60.0)
                      var sec_pay = min_pay?.div(60.0)

                      //소수점 만들기
                      pay_text = Math.round(sec_pay!!.toFloat()*1000)/1000.0

                      //////////////////////////////////////////////////////////////////////////
                      val runnable = object : Runnable {
                          @Override
                          override fun run() {
                              timeValue++
                              println("타임밸류 : " + timeValue)
                              //TextView업데이트 하기
                              timeToText(timeValue , pay_text , work_time!!.toInt())?.let {
                                  testView.text = it
                              }
                              handler.postDelayed(this, 10)
                          }
                      }//runnable

                      //시작버튼
                      bt_start.setOnClickListener{
                          handler.post(runnable)
                      }
                     /* bt_start.setOnClickListener(View.OnClickListener() {
                              @Override
                              override fun onSingleClick(v : View) {

                                  if (SystemClock.elapsedRealtime() - mLastCLickTIme < 1000) {
                                      return
                                  }
                                  println("버튼START")
                                  mLastCLickTIme = SystemClock.elapsedRealtime()
                                  handler.post(runnable)
                              }

                      })*/

                      //완료버튼
                      timeover.setOnClickListener{
                          handler.removeCallbacks(runnable)
                          val intent = Intent(this@ResultActivity, SecondActivity::class.java)
                          startActivity(intent)
                      }
                  }
              })

    }//oncreate


    //뒤로가기 2번으로 앱 종료
    override fun onBackPressed() {
        //뒤로가기 버튼 클릭
        if(System.currentTimeMillis() - mBackWait >= 2000){
            mBackWait = System.currentTimeMillis()
            println("뒤로가기버튼 : " + mBackWait)
            Toast.makeText(this, "뒤로가기 버튼을 한번 더 누르면 종료됩니다." , Toast.LENGTH_LONG).show()
        }else{
            finish() //액티비티 종료
        }
    }

    private fun timeToText(time:Int = 0 , pay_text:Double , work_time: Int) : String? {
        var hour = (time / 144000) % 24 // 1시간
        var min = (time / 6000) % 60 // 1분
        var sec = (time / 100) % 60 // 1초
        var milli = time % 100 // 0.01초

        //급여 계산
        if (milli == 0) {
            sec_pay_result += pay_text
        }
        if (sec == 59) {
            min_pay_result = pay_text * 60
        }

        if (sec == work_time) { //여기서 시간 바꿔주면댐
            println("time_limit 1 : " + time_limit)
            if (timeover.getVisibility() == View.INVISIBLE) {
                timeover.setVisibility(View.VISIBLE)
                Toast.makeText(
                    this@ResultActivity,
                    "오늘도 수고하셨습니다 !! 이제부터 연장근무 수당으로 계산됩니다.",
                    Toast.LENGTH_LONG
                ).show()
                //알람보내기
                //https://developer.android.com/training/notify-user/build-notification?hl=ko
/*                val intent = Intent(this, ResultActivity::class.java)
                val pIntent = PendingIntent.getActivity(this, System.currentTimeMillis().toInt(), intent , 0)

                val n1 = NotificationCompat.Builder(this)
                    .setContentTitle("근무시간 종료")
                    .setContentText("근무시간 종료. 연장근무로 계산됩니다.")
                    .setSmallIcon(R.drawable.common_google_signin_btn_icon_dark)
                    .setContentIntent(pIntent)
                    .setAutoCancel(true)

                //NotificationManagerCompat.from(this).notify(0 , n1.build())
                //timerTask?.cancel()*/
            }
        }else if(sec >= work_time) {
            //야근수당 구현
            //5인 이상 사업장 : 통상시급 x 1.5 x 연장근로한 시간
            //5인 미만 사업장 : 통상시급 x 1 x 연장근로한 시간
            salary_count = (time / 100) % 60
            sec_view.text = String.format("%.2f", sec_pay_result * 1.5 * (salary_count-work_time))
            min_view.text = String.format("%.2f", min_pay_result)
            println("초당급여 카운트 : " + sec_pay_result * 1.5 * (salary_count-work_time))
        }else{
            //초당급여
            sec_view.text = String.format("%.2f", sec_pay_result)
            min_view.text = String.format("%.2f", min_pay_result)
        }

        return if (time < 0) {
            null
        } else if (time == 0) {
            "00:00:00.00"
        } else {
            "%1$02d:%2$02d:%3$02d.%4$02d".format(hour, min, sec , milli)
        }
    }//timeToText

    //intent로 갤러리 앱을 접근함
    private fun openGallery(){

        val intent = Intent(Intent.ACTION_GET_CONTENT)
        intent.setType("image/*")
        startActivityForResult(intent, OPEN_GALLERY)

    }

    @Override
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if(resultCode == Activity.RESULT_OK){
            if(requestCode == OPEN_GALLERY){

                var currentImageUrl : Uri? = data?.data
                try {
                    val bitmap = MediaStore.Images.Media.getBitmap(contentResolver , currentImageUrl)
                    cameraImage.setImageBitmap(bitmap)
                }catch (e:Exception){
                    e.printStackTrace()
                }
            }else{
                println("갤러리 접근 실패")
            }
        }
    }
/*

    private fun time_start(pay_text : Double , work_time : Int) = runBlocking {

             val job = GlobalScope.launch {
                    timerTask = timer(period = 10) {
                            time++
                            var hour = (time / 144000) % 24 // 1시간
                            var min = (time / 6000) % 60 // 1분
                            var sec = (time / 100) % 60 // 1초
                            var milli = time % 100 // 0.01초

                        //급여 계산
                        if (milli == 0) {
                            sec_pay_result += pay_text
                        }
                        if (sec == 59) {
                            min_pay_result = pay_text * 60
                        }
                        runOnUiThread {
                            //UI작업
                            if (sec == work_time) { //여기서 시간 바꿔주면댐
                                println("time_limit 1 : " + time_limit)
                                if (timeover.getVisibility() == View.INVISIBLE) {
                                    timeover.setVisibility(View.VISIBLE)
                                    Toast.makeText(
                                        this@ResultActivity,
                                        "오늘도 수고하셨습니다 !! 이제부터 연장근무 수당으로 계산됩니다.",
                                        Toast.LENGTH_LONG
                                    ).show()
                                    //timerTask?.cancel()
                                }

                            } */
                            /*else if(sec >= work_time) {
                                //야근수당
                                //5인 이상 사업장 : 통상시급 x 1.5 x 연장근로한 시간
                                //5인 미만 사업장 : 통상시급 x 1 x 연장근로한 시간
                                sec_view.text = String.format("%.2f", sec_pay_result)
                                min_view.text = String.format("%.2f", min_pay_result)

                            } *//*
                            else{
                                //초당급여
                                sec_view.text = String.format("%.2f", sec_pay_result)
                                min_view.text = String.format("%.2f", min_pay_result)
                            }
                        }//UI
                    }
                }
    }//time_start
*/

}//class

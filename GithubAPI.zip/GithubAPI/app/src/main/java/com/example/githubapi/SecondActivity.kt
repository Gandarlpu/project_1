package com.example.githubapi

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.FirebaseDatabase
import kotlinx.android.synthetic.main.activity_second.*

class SecondActivity : AppCompatActivity() {

    private var uid : String = ""
    private var work_start = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)

        //Intent에 string_uid로 넘어온 데이터를 받아줍니다.
        if(intent.hasExtra("string_uid")){
            var uid = intent.getStringExtra("string_uid")
            //Intent로 넘어온 데이터를 uid변수에 담아준다.
        }

        input_button.setOnClickListener{

            val databse = FirebaseDatabase.getInstance()
            val myRef = databse.getReference()
            //getReference는 uid의 정보

            //NULL값 처리
            if(work_time.text.toString().length <= 0 ||
                    salary.text.toString().length <= 0 ||
                    work_day.text.toString().length <= 0) {
                Toast.makeText(this, "값을 입력하세요.", Toast.LENGTH_LONG).show()
            }else {
                val Input = Data(
                    work_time.text.toString().toInt(),
                    salary.text.toString().toInt(),
                    work_day.text.toString().toInt(),
                    work_start
                )
                //Data코틀린에 매개변수로 넘기고 받아옴

                myRef.child(uid).setValue(Input)
                //myRef는 DB의 구조를 받아오는 변수
                //uid들을child라고 한다 새끼친다는 느낌?
                //입력받아온 값들(Input)을 DB에 넣어준다.

                //ResultAct로 넘겨주기
                val intent = Intent(this, ResultActivity::class.java)
                intent.putExtra("uid", uid)
                startActivity(intent)
                //파이어베이스에값을 받아와야되는데 여러값이 있으면 뭘받아야될지모르는데
                //내 uid에 맞는걸 갖고와야함으로 uid값으로 비교

            }
        }
    }

    /*private fun showTime() {
        //getReference는 uid의 정보
            val timePickerDialog = TimePickerDialog(
                this,
                OnTimeSetListener { view, hourOfDay, minute ->
                    var hour = hourOfDay
                    var min = minute

                    println(hour)
                    println(min)

                    work_start = hour

                }, 21, 12, true
            )

            timePickerDialog.setMessage("근무 시간 입력")
            timePickerDialog.show()

    }*/
}

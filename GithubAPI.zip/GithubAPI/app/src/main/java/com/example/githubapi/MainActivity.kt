package com.example.githubapi

import android.app.Activity
import android.content.Intent
import android.graphics.Point
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import kotlinx.android.synthetic.main.activity_main.*


class MainActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth// ...
    private var string_uid : String=""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize Firebase Auth
        auth = FirebaseAuth.getInstance()
        //이미 로그인한 경우 user에 유저정보가 담깁니다.
        val user = auth.currentUser

        //버튼 클릭시 로그인 실행
        button_setting.setOnClickListener{
            auth.signInAnonymously()
                .addOnCompleteListener(this) { task ->
                    if (user != null) {

                        //로그인한 적이 있는경우
                        string_uid = user.uid
                        Toast.makeText(this, "환영합니다" + string_uid + "님"
                                        ,Toast.LENGTH_SHORT).show()

                        ///////////////////////////////////////////////////////////////////
                        val intent = Intent(this, SecondActivity::class.java)
                        intent.putExtra("string_uid" , string_uid)
                        startActivity(intent)
                        //인텐트를 통해 입력된 값들을 SecondActivity로 넘김

                    } else {
                        //로그인한 적이 없는 경우
                        //로그인 구현
                        auth.signInAnonymously()
                            .addOnCompleteListener(this) { task ->
                                if (task.isSuccessful) {
                                    // 로그인 성공
                                    Toast.makeText(this, "로그인 성공" ,
                                        Toast.LENGTH_SHORT).show()

                                    val user = auth.currentUser
                                    string_uid = user!!.uid

                                    /////////////////////////////////////////////////////////////////////
                                    val intent = Intent(this, SecondActivity::class.java)
                                    intent.putExtra("string_uid" , string_uid)
                                    startActivity(intent)
                                    //인텐트를 통해 입력된 값들을 SecondActivity로 넘김

                                } else {
                                    //로그인 실패할 경우
                                    Toast.makeText(this, "로그인 실패" ,
                                        Toast.LENGTH_SHORT).show()
                                }
                            }
                    }
                }
        }
    }//onCreate

    var standardSize_X = 0
    var standardSize_Y:Int = 0
    var density = 0f

    fun getStandardSize() {
        val ScreenSize = getScreenSize(this)
        density = resources.displayMetrics.density
        standardSize_X = (ScreenSize!!.x / density).toInt()
        standardSize_Y = (ScreenSize.y / density).toInt()
    }
    fun getScreenSize(activity: Activity): Point? {
        val display = activity.windowManager.defaultDisplay
        val size = Point()
        display.getSize(size)
        return size
    }


}
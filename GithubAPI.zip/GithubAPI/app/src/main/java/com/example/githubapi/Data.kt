package com.example.githubapi

data class Data( //파라미터 변수 초기화
    var work_time : Int = 0,
    var salary : Int = 0,
    var work_day : Int = 0,
    val work_start : Int = 0

)

